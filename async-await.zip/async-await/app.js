const BASE_URL = "https://jsonplaceholder.typicode.com";

// GET
async function obtenerTodosLosPosts() { // Esta es una función asíncrona, lo que significa que puede contener código que se ejecute de manera asíncrona, como llamadas a APIs, temporizadores, etc. El uso de la palabra "ascync" permite que nuestra función pueda utilizar la palabra "await" para esperar a que se resuelvan las promesas antes de continuar con la ejecución del código.
    try{
        const response = await fetch(`${BASE_URL}/posts`); // Declaro una constante llamada "response" y le asigno el resultado de la función "fetch", en la cual básicamente le estoy diciendo que haga una petición al BASE_URL. La palabra "await", le indica a JavaScript que espere a que la promesa devuelta por "fetch" se resuelva antes de continuar con la ejecución de la función; es importante mencionar que esto no detiene el resto de nuestro programa, solo pausa la ejecución de la función asíncrona hasta obtener la respuesta.
        if(response.ok){
            const data = await response.json(); // Si la respuesta es exitosa, declaro una constante llamada "data", y le asigno el valor de convertir la respuesta a formato JSON. Utilizo nuevamente "await" para esperar que la promesa me devuelva el resultado de la conversión a JSON.
            console.log(data); // Imprimo en consola el resultado obtenido.
            const getResultDiv = document.getElementById("get-result");
            getResultDiv.innerHTML = ""; // Limpiamos el contenido previo (En caso de que hayan existido peticiones anteriores)
            getResultDiv.innerHTML = `<p style="color: green;"><strong>Posts obtenidos correctamente:</strong> ${JSON.stringify(data)}</p>`;  // Asignamos un nuevo contenido HTML al elemento getResultDiv.
        } else{
            throw new Error(`Error en la respuesta: ${response.status}`); // Si la respuesta no es exitosa, lanzo un error con un mensaje que incluye el código de estado de la respuesta.
        }
    }catch(error){
        console.error("Error al obtener los posts: ", error);
    }finally{
        console.log("Ejecución de la función obtenerTodosLosPosts finalizada");
    }
}

async function obtenerUnPost() {

}

// POST
async function crearPost() {

}

// PUT
async function actualizarPost() {

}

// DELETE
async function eliminarPost() {

}

document.getElementById("btn-get-all").addEventListener("click", obtenerTodosLosPosts);
document.getElementById("btn-get-one").addEventListener("click", obtenerUnPost);
document.getElementById("btn-post").addEventListener("click", crearPost);
document.getElementById("btn-put").addEventListener("click", actualizarPost);
document.getElementById("btn-delete").addEventListener("click", eliminarPost);
